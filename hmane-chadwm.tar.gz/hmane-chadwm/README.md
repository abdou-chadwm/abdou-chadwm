# hmane-chadwm
A personalized fork of siduck/chadwm with visual tweaks, custom keybindings, and layout adjustments to better fit my workflow.
