#!/usr/bin/env bash
#
#
xautolock -time 2 -locker "i3lock --clock --blur=sigma" && echo mem ? /sys/power/state
